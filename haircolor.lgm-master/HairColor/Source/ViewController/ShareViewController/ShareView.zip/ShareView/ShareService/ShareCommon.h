//
//  ShareCommon.h
//  EyeColor4.0
//
//  Created by ZB_Mac on 15-1-20.
//  Copyright (c) 2015年 ZB_Mac. All rights reserved.
//

#include "ZBCommonDefine.h"

#ifndef EyeColor4_0_ShareCommon_h
#define EyeColor4_0_ShareCommon_h

#define SHARE_SDK_ID @"26c13bafd566"

#define SINA_WEIBO_KEY @"568898243"
#define SINA_WEIBO_SECRET @"38a4f8204cc784f81f9f0daaf31e02e3"
#define SINA_WEIBO_URI @"http://www.sharesdk.cn"

#define TC_WEIBO_KEY @"801526884"
#define TC_WEIBO_SECRET @"1ce1fd9ddb742357ec2b5cba40c97ee3"
#define TC_WEIBO_URI APP_URL

#define WECHAT_APPID @"wxdabfffa94c897861"
#define WECHAT_SECRET @"202984309dde3f2e1f2df9e08dddbc13"

#define QQ_APP_ID @"100371282"
#define QQ_APP_KEY @"DyP5PzAkFtBGYOmg"
#define QQ_APP_SECRET @"aed9b0303e3ed1e27bae87c33761161d"

#define FB_KEY @"107704292745179"
#define FB_SECRET @"38053202e1a5fe26c80c753071f0b573"

#define TWITTER_KEY @"LRBM0H75rWrU9gNHvlEAA2aOy"
#define TWITTER_SECRET @"gbeWsZvA9ELJSdoBzJ5oLKX0TU09UOwrzdGfo9Tg7DjyGuMe8G"
#define TWITTER_URI @"http://mob.com"

#define LINKEDIN_KEY @"ejo5ibkye3vo"
#define LINKEDIN_SECRET @"cC7B2jpxITqPLZ5M"
#define LINKEDIN_URI @"http://sharesdk.cn"

#define FLICKR_KEY @"33d833ee6b6fca49943363282dd313dd"
#define FLICKR_SECRET @"3a2c5b42a8fbb8bb"

#define TUMBLR_KEY @"2QUXqO9fcgGdtGG1FcvML6ZunIQzAEL8xY6hIaxdJnDti2DYwM"
#define TUMBLR_SECRET @"3Rt0sPFj7u2g39mEVB3IBpOzKnM3JnTtxX2bao2JKk4VV1gtNo"
#define TUMBLR_URL @"http://sharesdk.cn"

#define DROPBOX_KEY @"7janx53ilz11gbs"
#define DROPBOX_SECRET @"c1hpx5fz6tzkm32"

#define VKONTAKTE_KEY @"3921561"
#define VKONTAKTE_SECRET @"6Qf883ukLDyz4OBepYF1"

#define IG_APP_ID @"ff68e3216b4f4f989121aa1c2962d058"
#define IG_APP_SECRET @"1b2e82f110264869b3505c3fe34e31a1"
#define IG_APP_URI @"http://sharesdk.cn"


#endif
